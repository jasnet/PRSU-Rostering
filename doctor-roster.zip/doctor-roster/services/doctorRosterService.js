function generateDoctorRoster(doctor) {
    const days = [
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday"
    ];

    const majorPattern = [
        "OPD",
        "OT",
        "OPD",
        "OT",
        "Personal Agenda",
        "OPD"
    ];

    const minorPattern = [
        "OPD",
        "OPD",
        "Personal Agenda",
        "OPD",
        "OPD",
        "OPD"
    ];

    const pattern =
        doctor.departmentType === "Major"
            ? majorPattern
            : minorPattern;

    const schedule = [];

    for (let i = 0; i < days.length; i++) {
        schedule.push({
            day: days[i],
            activity: pattern[i]
        });
    }

    return schedule;
}

module.exports = generateDoctorRoster;