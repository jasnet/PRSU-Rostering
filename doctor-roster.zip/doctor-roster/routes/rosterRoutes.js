const express = require("express");
const router = express.Router();

const Doctor = require("../models/Doctor");
const generateDoctorRoster = require("../services/doctorRosterService");

router.get("/generate/:doctorId", async (req, res) => {
    try {
        const doctor = await Doctor.findOne({
            doctorId: req.params.doctorId
        });

        if (!doctor) {
            return res.status(404).json({
                message: "Doctor not found"
            });
        }

        const schedule = generateDoctorRoster(doctor);

        res.json({
            doctorId: doctor.doctorId,
            name: doctor.name,
            departmentType: doctor.departmentType,
            schedule
        });
    } catch (error) {
        res.status(500).json({
            message: error.message
        });
    }
});

module.exports = router;