from datetime import datetime

psychiatry_clinics = {
    "Monday": "Psychomotor and Neuropsychiatry Clinic",
    "Tuesday": "De-addiction Clinic",
    "Wednesday": "Child Psychiatry Clinic",
    "Thursday": "Family Counselling and Marital Therapy",
    "Friday": "Geriatric Mental Health Clinic",
    "Saturday": "OPD",
}


def create_slot(day, activity, details=""):
    start_time = "09:00 AM"
    end_time = "04:30 PM"

    if activity == "OT":
        start_time = "08:00 AM"
        end_time = "02:00 PM"
        details = details or "Scheduled Surgery"

    if activity == "Personal Agenda":
        start_time = "10:00 AM"
        end_time = "01:00 PM"
        details = details or "Teaching / Research / Meetings"

    return {
        "day": day,
        "activity": activity,
        "startTime": start_time,
        "endTime": end_time,
        "details": details,
    }


def generate_major_roster():
    return [
        create_slot("Monday", "OPD", "Patient Consultation and Teaching"),
        create_slot("Tuesday", "OT"),
        create_slot("Wednesday", "OPD", "Patient Consultation and Teaching"),
        create_slot("Thursday", "OT"),
        create_slot("Friday", "Personal Agenda"),
        create_slot("Saturday", "OPD", "Patient Consultation and Teaching"),
    ]


def generate_psychiatry_roster():
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    return [
        create_slot(day, psychiatry_clinics.get(day, "OPD"), "Specialty Clinic / OPD")
        for day in days
    ]


def generate_minor_roster():
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"]
    roster = []
    for index, day in enumerate(days):
        if index == 2:
            roster.append(create_slot(day, "Personal Agenda"))
        else:
            roster.append(create_slot(day, "OPD", "Patient Consultation and Teaching"))
    return roster


def generate_doctor_roster(doctor: dict):
    # doctor expected keys: doctorId, department, departmentType, name
    if doctor.get("departmentType") == "Major":
        return generate_major_roster()

    if doctor.get("department") == "Psychiatry":
        return generate_psychiatry_roster()

    return generate_minor_roster()
