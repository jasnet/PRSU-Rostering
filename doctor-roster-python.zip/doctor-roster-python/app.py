from flask import Flask, request, jsonify
from flask_cors import CORS
from pymongo import MongoClient
from datetime import datetime
from services.doctor_roster_service import generate_doctor_roster

app = Flask(__name__)
CORS(app)

client = MongoClient("mongodb://127.0.0.1:27017")
db = client.doctor_roster

def sanitize(doc):
    if not doc:
        return None
    doc = dict(doc)
    doc.pop("_id", None)
    return doc


@app.route("/", methods=["GET"])
def health():
    return "Doctor Roster API Running", 200


@app.route("/api/doctors", methods=["GET"])
def get_doctors():
    docs = list(db.doctors.find().sort("name", 1))
    result = [sanitize(d) for d in docs]
    return jsonify(result), 200


@app.route("/api/departments", methods=["GET"])
def get_departments():
    docs = list(db.departments.find().sort("name", 1))
    result = [sanitize(d) for d in docs]
    return jsonify(result), 200


@app.route("/api/doctors", methods=["POST"])
def create_doctor():
    data = request.get_json()
    if not data or "doctorId" not in data:
        return jsonify({"message": "doctorId required"}), 400
    db.doctors.insert_one(data)
    return jsonify(data), 201


@app.route("/api/rosters/generate/<doctorId>", methods=["GET"])
def generate_roster(doctorId):
    doctor = db.doctors.find_one({"doctorId": doctorId})
    if not doctor:
        return jsonify({"message": "Doctor not found"}), 404

    schedule = generate_doctor_roster(doctor)
    roster = {
        "doctorId": doctor.get("doctorId"),
        "doctorName": doctor.get("name"),
        "department": doctor.get("department"),
        "weekStartDate": datetime.utcnow(),
        "schedule": schedule,
    }
    db.rosters.insert_one(roster)
    roster.pop("_id", None)
    return jsonify(roster), 200


@app.route("/api/rosters/<doctorId>", methods=["GET"])
def get_roster(doctorId):
    roster = db.rosters.find_one({"doctorId": doctorId})
    if not roster:
        return jsonify({"message": "Roster not found"}), 404
    roster = sanitize(roster)
    return jsonify(roster), 200


if __name__ == "__main__":
    app.run(port=5000, debug=True)
