from pymongo import MongoClient

client = MongoClient("mongodb://127.0.0.1:27017")
db = client.doctor_roster

sample_departments = [
    "General Medicine",
    "General Surgery",
    "Obstetrics & Gynaecology (OBG)",
    "Pediatrics",
    "Orthopedics",
    "Dermatology (DVL)",
    "Psychiatry",
    "ENT (Ear, Nose, Throat)",
    "Ophthalmology",
    "Anaesthesiology",
    "Radio Diagnosis (Radiology)",
    "Dentistry",
    "Emergency & Trauma Care",
]

sample_doctors = [
    {
        "doctorId": "D001",
        "name": "Dr. Keya Das",
        "department": "Psychiatry",
        "departmentType": "Minor",
    },
    {
        "doctorId": "D002",
        "name": "Dr. Bhavyasree",
        "department": "Dentistry",
        "departmentType": "Minor",
    },
    {
        "doctorId": "D003",
        "name": "Dr. A. General",
        "department": "General Surgery",
        "departmentType": "Major",
    },
    {
        "doctorId": "D004",
        "name": "Dr. Priya Nair",
        "department": "General Medicine",
        "departmentType": "Major",
    },
    {
        "doctorId": "D005",
        "name": "Dr. Ravi Kumar",
        "department": "Obstetrics & Gynaecology (OBG)",
        "departmentType": "Major",
    },
    {
        "doctorId": "D006",
        "name": "Dr. Sunita Patel",
        "department": "Pediatrics",
        "departmentType": "Major",
    },
    {
        "doctorId": "D007",
        "name": "Dr. Anil Singh",
        "department": "Orthopedics",
        "departmentType": "Major",
    },
    {
        "doctorId": "D008",
        "name": "Dr. Neha Sharma",
        "department": "Dermatology (DVL)",
        "departmentType": "Major",
    },
    {
        "doctorId": "D009",
        "name": "Dr. Meera Iyer",
        "department": "Ophthalmology",
        "departmentType": "Major",
    },
    {
        "doctorId": "D010",
        "name": "Dr. Amit Desai",
        "department": "Anaesthesiology",
        "departmentType": "Major",
    },
    {
        "doctorId": "D011",
        "name": "Dr. Farhan Khan",
        "department": "Radio Diagnosis (Radiology)",
        "departmentType": "Major",
    },
    {
        "doctorId": "D012",
        "name": "Dr. Kavita Rao",
        "department": "Emergency & Trauma Care",
        "departmentType": "Major",
    },
    {
        "doctorId": "D013",
        "name": "Dr. Suresh Bhat",
        "department": "ENT (Ear, Nose, Throat)",
        "departmentType": "Major",
    },
]


def seed():
    db.departments.delete_many({})
    db.doctors.delete_many({})
    db.rosters.delete_many({})
    db.departments.insert_many([{"name": name} for name in sample_departments])
    db.doctors.insert_many(sample_doctors)
    print("Seeded departments and doctors")


if __name__ == "__main__":
    seed()
